import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        base: {
          DEFAULT: "#070B18",
          light: "#0D1326",
          lighter: "#141B36",
          border: "#1E2646"
        },
        accent: {
          pink: "#FF2E9F",
          purple: "#8B5CF6",
          blue: "#3B82F6"
        }
      },
      backgroundImage: {
        "geo-gradient": "linear-gradient(135deg, #FF2E9F 0%, #8B5CF6 50%, #3B82F6 100%)",
        "geo-gradient-soft": "linear-gradient(135deg, rgba(255,46,159,0.15) 0%, rgba(139,92,246,0.15) 50%, rgba(59,130,246,0.15) 100%)",
        "geo-radial": "radial-gradient(circle at 50% 0%, rgba(139,92,246,0.25), transparent 60%)"
      },
      boxShadow: {
        "neon-pink": "0 0 20px rgba(255,46,159,0.5)",
        "neon-purple": "0 0 20px rgba(139,92,246,0.5)",
        "neon-blue": "0 0 20px rgba(59,130,246,0.5)",
        glass: "0 8px 32px rgba(0,0,0,0.37)"
      },
      backdropBlur: {
        xs: "2px"
      },
      borderRadius: {
        xl2: "1.25rem"
      },
      keyframes: {
        "fade-in": { "0%": { opacity: "0" }, "100%": { opacity: "1" } },
        "slide-up": { "0%": { opacity: "0", transform: "translateY(12px)" }, "100%": { opacity: "1", transform: "translateY(0)" } },
        glow: { "0%,100%": { opacity: "0.6" }, "50%": { opacity: "1" } }
      },
      animation: {
        "fade-in": "fade-in 0.4s ease-out",
        "slide-up": "slide-up 0.4s ease-out",
        glow: "glow 2.4s ease-in-out infinite"
      },
      fontFamily: {
        sans: ["var(--font-inter)", "sans-serif"],
        display: ["var(--font-sora)", "sans-serif"]
      }
    }
  },
  plugins: []
};

export default config;

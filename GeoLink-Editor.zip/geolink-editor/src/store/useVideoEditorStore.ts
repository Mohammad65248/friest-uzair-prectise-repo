import { create } from "zustand";
import { v4 as uuid } from "uuid";
import type { TimelineClip, TimelineTrack } from "@/types";

interface VideoEditorState {
  tracks: TimelineTrack[];
  currentTime: number;
  duration: number;
  playing: boolean;
  selectedClipId: string | null;
  zoomPxPerSecond: number;

  addVideoClip: (file: File, url: string, duration: number) => void;
  addTextClip: (text: string, start: number, duration: number) => void;
  removeClip: (clipId: string) => void;
  splitClipAt: (clipId: string, time: number) => void;
  trimClip: (clipId: string, trimStart: number, trimEnd: number) => void;
  moveClip: (clipId: string, newStart: number) => void;
  selectClip: (clipId: string | null) => void;
  setCurrentTime: (t: number) => void;
  setPlaying: (p: boolean) => void;
  setZoom: (z: number) => void;
  recalcDuration: () => void;
}

function ensureTrack(tracks: TimelineTrack[], type: TimelineTrack["type"]): TimelineTrack[] {
  if (tracks.some((t) => t.type === type)) return tracks;
  return [
    ...tracks,
    {
      id: uuid(),
      type,
      name: type === "video" ? "Video 1" : type === "text" ? "Text 1" : "Audio 1",
      clips: [],
      locked: false,
      hidden: false
    }
  ];
}

export const useVideoEditorStore = create<VideoEditorState>((set, get) => ({
  tracks: [],
  currentTime: 0,
  duration: 0,
  playing: false,
  selectedClipId: null,
  zoomPxPerSecond: 40,

  addVideoClip: (file, url, duration) => {
    set((state) => {
      const tracks = ensureTrack(state.tracks, "video");
      const track = tracks.find((t) => t.type === "video")!;
      const lastEnd = track.clips.reduce((max, c) => Math.max(max, c.start + c.duration), 0);
      const clip: TimelineClip = {
        id: uuid(),
        trackId: track.id,
        name: file.name,
        type: "video",
        src: url,
        start: lastEnd,
        duration,
        trimStart: 0,
        trimEnd: duration,
        volume: 1
      };
      track.clips.push(clip);
      return { tracks: [...tracks] };
    });
    get().recalcDuration();
  },

  addTextClip: (text, start, duration) => {
    set((state) => {
      const tracks = ensureTrack(state.tracks, "text");
      const track = tracks.find((t) => t.type === "text")!;
      const clip: TimelineClip = {
        id: uuid(),
        trackId: track.id,
        name: text.slice(0, 20),
        type: "text",
        text,
        start,
        duration,
        trimStart: 0,
        trimEnd: duration
      };
      track.clips.push(clip);
      return { tracks: [...tracks] };
    });
    get().recalcDuration();
  },

  removeClip: (clipId) => {
    set((state) => ({
      tracks: state.tracks.map((t) => ({
        ...t,
        clips: t.clips.filter((c) => c.id !== clipId)
      }))
    }));
    get().recalcDuration();
  },

  splitClipAt: (clipId, time) => {
    set((state) => ({
      tracks: state.tracks.map((t) => ({
        ...t,
        clips: t.clips.flatMap((c) => {
          if (c.id !== clipId) return [c];
          const localTime = time - c.start;
          if (localTime <= 0.05 || localTime >= c.duration - 0.05) return [c];
          const first: TimelineClip = {
            ...c,
            duration: localTime,
            trimEnd: c.trimStart + localTime
          };
          const second: TimelineClip = {
            ...c,
            id: uuid(),
            start: c.start + localTime,
            duration: c.duration - localTime,
            trimStart: c.trimStart + localTime
          };
          return [first, second];
        })
      }))
    }));
  },

  trimClip: (clipId, trimStart, trimEnd) => {
    set((state) => ({
      tracks: state.tracks.map((t) => ({
        ...t,
        clips: t.clips.map((c) =>
          c.id === clipId
            ? { ...c, trimStart, trimEnd, duration: trimEnd - trimStart }
            : c
        )
      }))
    }));
    get().recalcDuration();
  },

  moveClip: (clipId, newStart) => {
    set((state) => ({
      tracks: state.tracks.map((t) => ({
        ...t,
        clips: t.clips.map((c) =>
          c.id === clipId ? { ...c, start: Math.max(0, newStart) } : c
        )
      }))
    }));
    get().recalcDuration();
  },

  selectClip: (clipId) => set({ selectedClipId: clipId }),
  setCurrentTime: (t) => set({ currentTime: t }),
  setPlaying: (p) => set({ playing: p }),
  setZoom: (z) => set({ zoomPxPerSecond: z }),

  recalcDuration: () => {
    const { tracks } = get();
    const duration = tracks.reduce((max, t) => {
      const trackEnd = t.clips.reduce((m, c) => Math.max(m, c.start + c.duration), 0);
      return Math.max(max, trackEnd);
    }, 0);
    set({ duration });
  }
}));

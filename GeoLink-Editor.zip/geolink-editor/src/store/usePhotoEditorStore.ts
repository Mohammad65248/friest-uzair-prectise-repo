import { create } from "zustand";

export interface LayerMeta {
  id: string;
  name: string;
  type: "image" | "text" | "shape" | "brush" | "group";
  visible: boolean;
  locked: boolean;
  opacity: number;
  thumbnail?: string;
}

interface HistoryEntry {
  json: string;
  label: string;
}

interface PhotoEditorState {
  layers: LayerMeta[];
  activeLayerId: string | null;
  activeTool: string;
  history: HistoryEntry[];
  historyIndex: number;
  zoom: number;
  canvasReady: boolean;

  setLayers: (layers: LayerMeta[]) => void;
  setActiveLayer: (id: string | null) => void;
  setActiveTool: (tool: string) => void;
  pushHistory: (json: string, label: string) => void;
  undo: () => HistoryEntry | null;
  redo: () => HistoryEntry | null;
  setZoom: (zoom: number) => void;
  setCanvasReady: (ready: boolean) => void;
  reset: () => void;
}

const MAX_HISTORY = 60;

export const usePhotoEditorStore = create<PhotoEditorState>((set, get) => ({
  layers: [],
  activeLayerId: null,
  activeTool: "select",
  history: [],
  historyIndex: -1,
  zoom: 1,
  canvasReady: false,

  setLayers: (layers) => set({ layers }),
  setActiveLayer: (id) => set({ activeLayerId: id }),
  setActiveTool: (tool) => set({ activeTool: tool }),

  pushHistory: (json, label) => {
    const { history, historyIndex } = get();
    const trimmed = history.slice(0, historyIndex + 1);
    trimmed.push({ json, label });
    const overflow = trimmed.length - MAX_HISTORY;
    const finalHistory = overflow > 0 ? trimmed.slice(overflow) : trimmed;
    set({ history: finalHistory, historyIndex: finalHistory.length - 1 });
  },

  undo: () => {
    const { history, historyIndex } = get();
    if (historyIndex <= 0) return null;
    const newIndex = historyIndex - 1;
    set({ historyIndex: newIndex });
    return history[newIndex];
  },

  redo: () => {
    const { history, historyIndex } = get();
    if (historyIndex >= history.length - 1) return null;
    const newIndex = historyIndex + 1;
    set({ historyIndex: newIndex });
    return history[newIndex];
  },

  setZoom: (zoom) => set({ zoom }),
  setCanvasReady: (ready) => set({ canvasReady: ready }),
  reset: () =>
    set({
      layers: [],
      activeLayerId: null,
      activeTool: "select",
      history: [],
      historyIndex: -1,
      zoom: 1
    })
}));

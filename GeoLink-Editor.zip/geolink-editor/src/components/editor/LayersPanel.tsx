"use client";

import { Eye, EyeOff, Lock, Unlock, Trash2, Layers as LayersIcon } from "lucide-react";
import { usePhotoEditorStore } from "@/store/usePhotoEditorStore";
import { fabric } from "fabric";
import { AnimatePresence, motion } from "framer-motion";

interface LayersPanelProps {
  canvas: fabric.Canvas | null;
}

export default function LayersPanel({ canvas }: LayersPanelProps) {
  const { layers, activeLayerId, setActiveLayer, pushHistory } = usePhotoEditorStore();

  const findObject = (id: string) =>
    canvas?.getObjects().find((o) => (o as any).layerMeta?.id === id);

  const toggleVisibility = (id: string) => {
    const obj = findObject(id);
    if (!obj || !canvas) return;
    obj.visible = !obj.visible;
    canvas.requestRenderAll();
    pushHistory(JSON.stringify(canvas.toJSON(["layerMeta"])), "Toggle visibility");
  };

  const toggleLock = (id: string) => {
    const obj = findObject(id);
    if (!obj || !canvas) return;
    const meta = (obj as any).layerMeta;
    meta.locked = !meta.locked;
    obj.selectable = !meta.locked;
    obj.evented = !meta.locked;
    canvas.requestRenderAll();
  };

  const deleteLayer = (id: string) => {
    const obj = findObject(id);
    if (!obj || !canvas) return;
    canvas.remove(obj);
    canvas.requestRenderAll();
    pushHistory(JSON.stringify(canvas.toJSON(["layerMeta"])), "Delete layer");
  };

  const selectLayer = (id: string) => {
    const obj = findObject(id);
    if (!obj || !canvas) return;
    canvas.setActiveObject(obj);
    canvas.requestRenderAll();
    setActiveLayer(id);
  };

  const updateOpacity = (id: string, value: number) => {
    const obj = findObject(id);
    if (!obj || !canvas) return;
    obj.opacity = value;
    canvas.requestRenderAll();
  };

  return (
    <div className="flex flex-col gap-2 h-full">
      <div className="flex items-center gap-2 px-1 text-slate-300">
        <LayersIcon size={15} />
        <span className="text-xs font-semibold tracking-wide uppercase">
          Layers ({layers.length})
        </span>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar flex flex-col gap-1.5 pr-0.5">
        <AnimatePresence initial={false}>
          {layers.length === 0 && (
            <p className="text-xs text-slate-500 px-1 py-4 text-center">
              No layers yet. Add an image, text, or shape to get started.
            </p>
          )}
          {layers.map((layer) => (
            <motion.div
              key={layer.id}
              layout
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, height: 0 }}
              onClick={() => selectLayer(layer.id)}
              className={`group flex flex-col gap-1.5 rounded-xl px-2.5 py-2 cursor-pointer border transition-colors ${
                activeLayerId === layer.id
                  ? "bg-white/[0.08] border-accent-purple/40"
                  : "bg-white/[0.02] border-transparent hover:bg-white/[0.05]"
              }`}
            >
              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleVisibility(layer.id);
                  }}
                  className="text-slate-400 hover:text-white shrink-0"
                >
                  {layer.visible ? <Eye size={14} /> : <EyeOff size={14} />}
                </button>
                <span className="text-xs truncate flex-1 text-slate-200">{layer.name}</span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleLock(layer.id);
                  }}
                  className="text-slate-500 hover:text-white shrink-0"
                >
                  {layer.locked ? <Lock size={12} /> : <Unlock size={12} />}
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteLayer(layer.id);
                  }}
                  className="text-slate-500 hover:text-red-400 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 size={12} />
                </button>
              </div>
              {activeLayerId === layer.id && (
                <div className="flex items-center gap-2 pl-6">
                  <span className="text-[10px] text-slate-500 w-12">Opacity</span>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.01}
                    defaultValue={layer.opacity}
                    onChange={(e) => updateOpacity(layer.id, Number(e.target.value))}
                    className="geo-slider h-1"
                  />
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

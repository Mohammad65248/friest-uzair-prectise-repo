"use client";

import { useState } from "react";
import { fabric } from "fabric";
import { SlidersHorizontal, RotateCcw } from "lucide-react";
import {
  DEFAULT_ADJUSTMENTS,
  type AdjustmentValues
} from "@/types";
import { applyAdjustmentsToImage, ADJUSTMENT_LABELS } from "@/lib/applyAdjustments";
import { usePhotoEditorStore } from "@/store/usePhotoEditorStore";

interface AdjustmentsPanelProps {
  canvas: fabric.Canvas | null;
}

const GROUPS: (keyof AdjustmentValues)[][] = [
  ["brightness", "contrast", "exposure"],
  ["saturation", "vibrance", "hue"],
  ["temperature", "tint"],
  ["highlights", "shadows", "whites", "blacks"],
  ["sharpen", "clarity", "noiseReduction", "blur"]
];

export default function AdjustmentsPanel({ canvas }: AdjustmentsPanelProps) {
  const [values, setValues] = useState<AdjustmentValues>(DEFAULT_ADJUSTMENTS);
  const { activeLayerId, pushHistory } = usePhotoEditorStore();

  const activeImage = () => {
    if (!canvas || !activeLayerId) return null;
    const obj = canvas.getObjects().find((o) => (o as any).layerMeta?.id === activeLayerId);
    if (obj && obj.type === "image") return obj as fabric.Image;
    return null;
  };

  const handleChange = (key: keyof AdjustmentValues, val: number) => {
    const next = { ...values, [key]: val };
    setValues(next);
    const img = activeImage();
    if (img) applyAdjustmentsToImage(img, next);
  };

  const handleCommit = () => {
    if (!canvas) return;
    pushHistory(JSON.stringify(canvas.toJSON(["layerMeta"])), "Adjust image");
  };

  const resetAll = () => {
    setValues(DEFAULT_ADJUSTMENTS);
    const img = activeImage();
    if (img) applyAdjustmentsToImage(img, DEFAULT_ADJUSTMENTS);
  };

  const disabled = !activeImage();

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2 text-slate-300">
          <SlidersHorizontal size={15} />
          <span className="text-xs font-semibold tracking-wide uppercase">Adjustments</span>
        </div>
        <button
          onClick={resetAll}
          disabled={disabled}
          className="text-slate-500 hover:text-white disabled:opacity-30"
          title="Reset all"
        >
          <RotateCcw size={13} />
        </button>
      </div>

      {disabled && (
        <p className="text-xs text-slate-500 px-1">
          Select an image layer to edit tonal adjustments.
        </p>
      )}

      <div className={`flex flex-col gap-4 ${disabled ? "opacity-40 pointer-events-none" : ""}`}>
        {GROUPS.map((group, gi) => (
          <div key={gi} className="flex flex-col gap-3">
            {group.map((key) => (
              <div key={key} className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] text-slate-400">{ADJUSTMENT_LABELS[key]}</label>
                  <span className="text-[11px] text-slate-500 tabular-nums">{values[key]}</span>
                </div>
                <input
                  type="range"
                  min={key === "hue" ? -180 : -100}
                  max={key === "hue" ? 180 : 100}
                  value={values[key]}
                  onChange={(e) => handleChange(key, Number(e.target.value))}
                  onMouseUp={handleCommit}
                  onTouchEnd={handleCommit}
                  className="geo-slider"
                />
              </div>
            ))}
            {gi < GROUPS.length - 1 && <div className="geo-divider" />}
          </div>
        ))}
      </div>
    </div>
  );
}

"use client";

import { useRef } from "react";
import { fabric } from "fabric";
import { ImagePlus, Type, Square, Circle, Triangle } from "lucide-react";
import { v4 as uuid } from "uuid";
import { usePhotoEditorStore } from "@/store/usePhotoEditorStore";

interface InsertBarProps {
  canvas: fabric.Canvas | null;
}

export default function InsertBar({ canvas }: InsertBarProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { pushHistory, setActiveTool } = usePhotoEditorStore();

  const commit = (label: string) => {
    if (!canvas) return;
    pushHistory(JSON.stringify(canvas.toJSON(["layerMeta"])), label);
  };

  const addImageFromFile = (file: File) => {
    if (!canvas) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      fabric.Image.fromURL(dataUrl, (img) => {
        const scale = Math.min(600 / (img.width ?? 600), 400 / (img.height ?? 400), 1);
        img.set({
          left: 100,
          top: 100,
          scaleX: scale,
          scaleY: scale,
          layerMeta: {
            id: uuid(),
            name: file.name.replace(/\.[^.]+$/, ""),
            type: "image",
            visible: true,
            locked: false,
            opacity: 1
          }
        } as any);
        canvas.add(img);
        canvas.setActiveObject(img);
        canvas.requestRenderAll();
        commit("Add image");
      });
    };
    reader.readAsDataURL(file);
  };

  const addText = () => {
    if (!canvas) return;
    const text = new fabric.IText("Double-click to edit", {
      left: 150,
      top: 150,
      fontFamily: "Sora, sans-serif",
      fontSize: 42,
      fill: "#ffffff",
      layerMeta: {
        id: uuid(),
        name: "Text layer",
        type: "text",
        visible: true,
        locked: false,
        opacity: 1
      }
    } as any);
    canvas.add(text);
    canvas.setActiveObject(text);
    canvas.requestRenderAll();
    setActiveTool("select");
    commit("Add text");
  };

  const addShape = (kind: "rect" | "circle" | "triangle") => {
    if (!canvas) return;
    const common = {
      left: 180,
      top: 180,
      fill: "#8B5CF6",
      layerMeta: {
        id: uuid(),
        name: `${kind[0].toUpperCase()}${kind.slice(1)} shape`,
        type: "shape",
        visible: true,
        locked: false,
        opacity: 1
      }
    };
    let shape: fabric.Object;
    if (kind === "rect") {
      shape = new fabric.Rect({ ...common, width: 180, height: 120, rx: 12, ry: 12 } as any);
    } else if (kind === "circle") {
      shape = new fabric.Circle({ ...common, radius: 80 } as any);
    } else {
      shape = new fabric.Triangle({ ...common, width: 160, height: 140 } as any);
    }
    canvas.add(shape);
    canvas.setActiveObject(shape);
    canvas.requestRenderAll();
    setActiveTool("select");
    commit("Add shape");
  };

  return (
    <div className="flex items-center gap-1.5 glass-panel-solid rounded-2xl px-2 py-1.5">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) addImageFromFile(file);
          e.target.value = "";
        }}
      />
      <button
        onClick={() => fileInputRef.current?.click()}
        className="geo-icon-btn"
        title="Insert image"
      >
        <ImagePlus size={17} />
      </button>
      <button onClick={addText} className="geo-icon-btn" title="Insert text">
        <Type size={17} />
      </button>
      <div className="w-px h-5 bg-white/10" />
      <button onClick={() => addShape("rect")} className="geo-icon-btn" title="Rectangle">
        <Square size={17} />
      </button>
      <button onClick={() => addShape("circle")} className="geo-icon-btn" title="Circle">
        <Circle size={17} />
      </button>
      <button onClick={() => addShape("triangle")} className="geo-icon-btn" title="Triangle">
        <Triangle size={17} />
      </button>
    </div>
  );
}

"use client";

import {
  MousePointer2,
  Crop,
  Type,
  Paintbrush,
  Shapes,
  Eraser,
  Stamp,
  Wand2,
  Pipette,
  PaintBucket
} from "lucide-react";
import { usePhotoEditorStore } from "@/store/usePhotoEditorStore";
import type { ToolId } from "@/types";
import { motion } from "framer-motion";

const TOOLS: { id: ToolId; icon: React.ElementType; label: string }[] = [
  { id: "select", icon: MousePointer2, label: "Move / Select (V)" },
  { id: "crop", icon: Crop, label: "Crop (C)" },
  { id: "text", icon: Type, label: "Text (T)" },
  { id: "brush", icon: Paintbrush, label: "Brush (B)" },
  { id: "shape", icon: Shapes, label: "Shape (U)" },
  { id: "eraser", icon: Eraser, label: "Eraser (E)" },
  { id: "clone", icon: Stamp, label: "Clone Stamp (S)" },
  { id: "heal", icon: Wand2, label: "Healing Brush (H)" },
  { id: "gradient", icon: PaintBucket, label: "Gradient (G)" },
  { id: "eyedropper", icon: Pipette, label: "Eyedropper (I)" }
];

export default function Toolbar() {
  const { activeTool, setActiveTool } = usePhotoEditorStore();

  return (
    <div className="flex flex-col items-center gap-1 py-3 px-1.5 w-14 glass-panel-solid rounded-2xl">
      {TOOLS.map(({ id, icon: Icon, label }) => (
        <motion.button
          key={id}
          whileTap={{ scale: 0.9 }}
          title={label}
          onClick={() => setActiveTool(id)}
          className={`geo-icon-btn ${activeTool === id ? "active" : ""}`}
        >
          <Icon size={18} strokeWidth={2} />
        </motion.button>
      ))}
    </div>
  );
}

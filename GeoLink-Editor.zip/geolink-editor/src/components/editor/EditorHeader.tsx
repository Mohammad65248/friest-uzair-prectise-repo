"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { fabric } from "fabric";
import {
  Undo2,
  Redo2,
  ZoomIn,
  ZoomOut,
  Download,
  ChevronDown,
  ArrowLeft
} from "lucide-react";
import { usePhotoEditorStore } from "@/store/usePhotoEditorStore";
import { motion, AnimatePresence } from "framer-motion";

interface EditorHeaderProps {
  canvas: fabric.Canvas | null;
  projectName: string;
}

const EXPORT_FORMATS = ["PNG", "JPG", "WEBP", "SVG", "PDF"] as const;

export default function EditorHeader({ canvas, projectName }: EditorHeaderProps) {
  const { zoom, setZoom, undo, redo, history, historyIndex } = usePhotoEditorStore();
  const [exportOpen, setExportOpen] = useState(false);

  const loadHistoryState = (json: string) => {
    if (!canvas) return;
    canvas.loadFromJSON(json, () => canvas.requestRenderAll());
  };

  const handleUndo = () => {
    const entry = undo();
    if (entry) loadHistoryState(entry.json);
  };

  const handleRedo = () => {
    const entry = redo();
    if (entry) loadHistoryState(entry.json);
  };

  const exportAs = async (format: (typeof EXPORT_FORMATS)[number]) => {
    if (!canvas) return;
    setExportOpen(false);

    if (format === "SVG") {
      const svg = canvas.toSVG();
      const blob = new Blob([svg], { type: "image/svg+xml" });
      triggerDownload(URL.createObjectURL(blob), `${projectName}.svg`);
      return;
    }

    if (format === "PDF") {
      const dataUrl = canvas.toDataURL({ format: "png", quality: 1 });
      const { jsPDF } = await import("jspdf");
      const pdf = new jsPDF({
        orientation: canvas.getWidth()! > canvas.getHeight()! ? "landscape" : "portrait",
        unit: "px",
        format: [canvas.getWidth()!, canvas.getHeight()!]
      });
      pdf.addImage(dataUrl, "PNG", 0, 0, canvas.getWidth()!, canvas.getHeight()!);
      pdf.save(`${projectName}.pdf`);
      return;
    }

    const mime =
      format === "JPG" ? "jpeg" : format === "WEBP" ? "webp" : "png";
    const dataUrl = canvas.toDataURL({ format: mime, quality: 0.95 });
    triggerDownload(dataUrl, `${projectName}.${format.toLowerCase()}`);
  };

  const triggerDownload = (href: string, filename: string) => {
    const a = document.createElement("a");
    a.href = href;
    a.download = filename;
    a.click();
  };

  return (
    <header className="flex items-center justify-between px-4 py-2.5 glass-panel-solid rounded-2xl">
      <div className="flex items-center gap-3">
        <Link href="/dashboard" className="geo-icon-btn" title="Back to dashboard">
          <ArrowLeft size={16} />
        </Link>
        <div className="flex items-center gap-2">
          <Image
            src="/assets/logo/geolink-logo.png"
            alt="GeoLink Editor"
            width={26}
            height={26}
            className="drop-shadow-[0_0_8px_rgba(139,92,246,0.5)]"
          />
          <div className="flex flex-col leading-tight">
            <span className="text-sm font-display font-semibold text-white">{projectName}</span>
            <span className="text-[10px] text-slate-500">GeoLink Editor</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-1.5">
        <button
          onClick={handleUndo}
          disabled={historyIndex <= 0}
          className="geo-icon-btn disabled:opacity-30"
          title="Undo (Ctrl+Z)"
        >
          <Undo2 size={16} />
        </button>
        <button
          onClick={handleRedo}
          disabled={historyIndex >= history.length - 1}
          className="geo-icon-btn disabled:opacity-30"
          title="Redo (Ctrl+Shift+Z)"
        >
          <Redo2 size={16} />
        </button>
        <div className="w-px h-5 bg-white/10 mx-1" />
        <button
          onClick={() => setZoom(Math.max(0.1, zoom - 0.1))}
          className="geo-icon-btn"
          title="Zoom out"
        >
          <ZoomOut size={16} />
        </button>
        <span className="text-xs text-slate-400 w-10 text-center tabular-nums">
          {Math.round(zoom * 100)}%
        </span>
        <button
          onClick={() => setZoom(Math.min(4, zoom + 0.1))}
          className="geo-icon-btn"
          title="Zoom in"
        >
          <ZoomIn size={16} />
        </button>
      </div>

      <div className="relative">
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => setExportOpen((v) => !v)}
          className="geo-btn-primary text-sm"
        >
          <Download size={15} />
          Export
          <ChevronDown size={13} />
        </motion.button>
        <AnimatePresence>
          {exportOpen && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              className="absolute right-0 mt-2 w-40 glass-panel-solid rounded-xl p-1.5 z-50"
            >
              {EXPORT_FORMATS.map((fmt) => (
                <button
                  key={fmt}
                  onClick={() => exportAs(fmt)}
                  className="w-full text-left text-xs px-3 py-2 rounded-lg text-slate-300 hover:bg-white/10 hover:text-white"
                >
                  Export as {fmt}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}

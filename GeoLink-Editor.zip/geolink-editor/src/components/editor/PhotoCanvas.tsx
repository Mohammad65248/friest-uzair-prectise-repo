"use client";

import { useEffect, useRef, useCallback } from "react";
import { fabric } from "fabric";
import { usePhotoEditorStore, type LayerMeta } from "@/store/usePhotoEditorStore";
import { v4 as uuid } from "uuid";

interface PhotoCanvasProps {
  onCanvasReady: (canvas: fabric.Canvas) => void;
}

/**
 * PhotoCanvas is the real rendering engine for the photo editor.
 * It wraps Fabric.js, wires up layer <-> object sync, history
 * snapshots, and keyboard shortcuts (delete, undo/redo, nudge).
 */
export default function PhotoCanvas({ onCanvasReady }: PhotoCanvasProps) {
  const canvasElRef = useRef<HTMLCanvasElement>(null);
  const fabricRef = useRef<fabric.Canvas | null>(null);
  const {
    setLayers,
    setActiveLayer,
    pushHistory,
    activeTool,
    zoom,
    setCanvasReady
  } = usePhotoEditorStore();

  const syncLayersFromCanvas = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const objects = canvas.getObjects();
    const layers: LayerMeta[] = objects
      .map((obj) => {
        const meta = (obj as any).layerMeta as LayerMeta | undefined;
        if (!meta) return null;
        return {
          ...meta,
          visible: obj.visible !== false,
          opacity: obj.opacity ?? 1
        };
      })
      .filter(Boolean)
      .reverse() as LayerMeta[];
    setLayers(layers);
  }, [setLayers]);

  const snapshot = useCallback(
    (label: string) => {
      const canvas = fabricRef.current;
      if (!canvas) return;
      const json = JSON.stringify(
        canvas.toJSON(["layerMeta", "selectable", "evented"])
      );
      pushHistory(json, label);
    },
    [pushHistory]
  );

  useEffect(() => {
    if (!canvasElRef.current) return;

    const canvas = new fabric.Canvas(canvasElRef.current, {
      backgroundColor: "#0d1326",
      preserveObjectStacking: true,
      selection: true,
      width: 1200,
      height: 800
    });

    fabricRef.current = canvas;
    setCanvasReady(true);
    onCanvasReady(canvas);

    canvas.on("object:added", syncLayersFromCanvas);
    canvas.on("object:removed", syncLayersFromCanvas);
    canvas.on("object:modified", () => {
      syncLayersFromCanvas();
      snapshot("Modify object");
    });
    canvas.on("selection:created", (e) => {
      const obj = e.selected?.[0] as any;
      setActiveLayer(obj?.layerMeta?.id ?? null);
    });
    canvas.on("selection:updated", (e) => {
      const obj = e.selected?.[0] as any;
      setActiveLayer(obj?.layerMeta?.id ?? null);
    });
    canvas.on("selection:cleared", () => setActiveLayer(null));

    // Initial blank-canvas history state
    snapshot("New document");

    const handleKeyDown = (e: KeyboardEvent) => {
      const active = canvas.getActiveObject();
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;

      if ((e.key === "Delete" || e.key === "Backspace") && active) {
        e.preventDefault();
        if (canvas.getActiveObjects().length > 1) {
          canvas.getActiveObjects().forEach((o) => canvas.remove(o));
          canvas.discardActiveObject();
        } else {
          canvas.remove(active);
        }
        canvas.requestRenderAll();
        snapshot("Delete layer");
      }

      if (active && ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
        e.preventDefault();
        const step = e.shiftKey ? 10 : 1;
        if (e.key === "ArrowUp") active.top = (active.top ?? 0) - step;
        if (e.key === "ArrowDown") active.top = (active.top ?? 0) + step;
        if (e.key === "ArrowLeft") active.left = (active.left ?? 0) - step;
        if (e.key === "ArrowRight") active.left = (active.left ?? 0) + step;
        active.setCoords();
        canvas.requestRenderAll();
      }

      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === "d" && active) {
        e.preventDefault();
        active.clone((cloned: fabric.Object) => {
          cloned.set({
            left: (active.left ?? 0) + 20,
            top: (active.top ?? 0) + 20,
            layerMeta: {
              ...(active as any).layerMeta,
              id: uuid(),
              name: `${(active as any).layerMeta?.name ?? "Layer"} copy`
            }
          } as any);
          canvas.add(cloned);
          canvas.setActiveObject(cloned);
          snapshot("Duplicate layer");
        });
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      canvas.dispose();
      fabricRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Zoom sync
  useEffect(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    canvas.setZoom(zoom);
    canvas.setWidth(1200 * zoom);
    canvas.setHeight(800 * zoom);
    canvas.requestRenderAll();
  }, [zoom]);

  // Tool sync — controls drawing mode
  useEffect(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;

    canvas.isDrawingMode = activeTool === "brush" || activeTool === "eraser";
    canvas.selection = activeTool === "select";

    if (canvas.isDrawingMode) {
      canvas.freeDrawingBrush = new fabric.PencilBrush(canvas);
      canvas.freeDrawingBrush.width = activeTool === "eraser" ? 30 : 6;
      canvas.freeDrawingBrush.color =
        activeTool === "eraser" ? "#0d1326" : "#8B5CF6";
    }

    canvas.forEachObject((obj) => {
      obj.selectable = activeTool === "select";
      obj.evented = activeTool === "select";
    });
  }, [activeTool]);

  return (
    <div className="flex items-center justify-center w-full h-full overflow-auto checkerboard rounded-xl">
      <div className="shadow-2xl shadow-black/50 ring-1 ring-white/10 rounded-sm overflow-hidden">
        <canvas ref={canvasElRef} />
      </div>
    </div>
  );
}

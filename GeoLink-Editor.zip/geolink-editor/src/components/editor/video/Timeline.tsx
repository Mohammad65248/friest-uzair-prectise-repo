"use client";

import { useRef, useState } from "react";
import { useVideoEditorStore } from "@/store/useVideoEditorStore";
import type { TimelineClip } from "@/types";
import { Scissors, Trash2, Film, Type as TypeIcon, ZoomIn, ZoomOut } from "lucide-react";

export default function Timeline() {
  const {
    tracks,
    currentTime,
    duration,
    selectedClipId,
    zoomPxPerSecond,
    setCurrentTime,
    selectClip,
    moveClip,
    trimClip,
    splitClipAt,
    removeClip,
    setZoom
  } = useVideoEditorStore();

  const trackAreaRef = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState<{ clipId: string; startX: number; origStart: number } | null>(null);
  const [trimming, setTrimming] = useState<{ clipId: string; edge: "left" | "right"; startX: number } | null>(null);

  const px = zoomPxPerSecond;
  const totalWidth = Math.max(600, (duration + 10) * px);

  const timeFromClientX = (clientX: number) => {
    const rect = trackAreaRef.current?.getBoundingClientRect();
    if (!rect) return 0;
    return Math.max(0, (clientX - rect.left) / px);
  };

  const handleRulerClick = (e: React.MouseEvent) => {
    setCurrentTime(timeFromClientX(e.clientX));
  };

  const onClipMouseDown = (e: React.MouseEvent, clip: TimelineClip) => {
    e.stopPropagation();
    selectClip(clip.id);
    setDragging({ clipId: clip.id, startX: e.clientX, origStart: clip.start });
  };

  const onTrimHandleDown = (e: React.MouseEvent, clip: TimelineClip, edge: "left" | "right") => {
    e.stopPropagation();
    setTrimming({ clipId: clip.id, edge, startX: e.clientX });
  };

  const onMouseMove = (e: React.MouseEvent) => {
    if (dragging) {
      const deltaSec = (e.clientX - dragging.startX) / px;
      moveClip(dragging.clipId, dragging.origStart + deltaSec);
    }
    if (trimming) {
      const clip = tracks.flatMap((t) => t.clips).find((c) => c.id === trimming.clipId);
      if (!clip) return;
      const deltaSec = (e.clientX - trimming.startX) / px;
      if (trimming.edge === "left") {
        const newTrimStart = Math.max(0, clip.trimStart + deltaSec);
        if (newTrimStart < clip.trimEnd - 0.2) {
          trimClip(clip.id, newTrimStart, clip.trimEnd);
          moveClip(clip.id, clip.start + deltaSec);
        }
      } else {
        const newTrimEnd = Math.max(clip.trimStart + 0.2, clip.trimEnd + deltaSec);
        trimClip(clip.id, clip.trimStart, newTrimEnd);
      }
      setTrimming({ ...trimming, startX: e.clientX });
    }
  };

  const stopInteraction = () => {
    setDragging(null);
    setTrimming(null);
  };

  const trackIcon = (type: string) =>
    type === "video" ? <Film size={12} /> : type === "text" ? <TypeIcon size={12} /> : <Film size={12} />;

  return (
    <div className="flex flex-col gap-2 glass-panel-solid rounded-2xl p-3 h-64">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            className="geo-icon-btn"
            title="Split at playhead"
            onClick={() => {
              if (selectedClipId) splitClipAt(selectedClipId, currentTime);
            }}
          >
            <Scissors size={15} />
          </button>
          <button
            className="geo-icon-btn"
            title="Delete selected clip"
            onClick={() => {
              if (selectedClipId) removeClip(selectedClipId);
            }}
          >
            <Trash2 size={15} />
          </button>
        </div>
        <div className="flex items-center gap-1.5">
          <button className="geo-icon-btn" onClick={() => setZoom(Math.max(10, px - 10))}>
            <ZoomOut size={14} />
          </button>
          <button className="geo-icon-btn" onClick={() => setZoom(Math.min(200, px + 10))}>
            <ZoomIn size={14} />
          </button>
        </div>
      </div>

      <div
        className="flex-1 overflow-x-auto overflow-y-hidden relative"
        onMouseMove={onMouseMove}
        onMouseUp={stopInteraction}
        onMouseLeave={stopInteraction}
      >
        <div style={{ width: totalWidth }} className="relative h-full">
          {/* Ruler */}
          <div
            className="h-6 border-b border-white/10 relative cursor-pointer select-none"
            onClick={handleRulerClick}
          >
            {Array.from({ length: Math.ceil(totalWidth / px) }).map((_, i) => (
              <div
                key={i}
                className="absolute top-0 h-full flex items-end"
                style={{ left: i * px }}
              >
                <span className="text-[9px] text-slate-500 pl-1 border-l border-white/10 h-full flex items-end pb-0.5">
                  {i}s
                </span>
              </div>
            ))}
          </div>

          {/* Playhead */}
          <div
            className="absolute top-0 bottom-0 w-px bg-accent-pink z-20 pointer-events-none"
            style={{ left: currentTime * px }}
          >
            <div className="w-2.5 h-2.5 -ml-[5px] -mt-0.5 rotate-45 bg-accent-pink" />
          </div>

          {/* Tracks */}
          <div ref={trackAreaRef} className="flex flex-col gap-1.5 mt-2">
            {tracks.length === 0 && (
              <p className="text-xs text-slate-500 py-6 text-center">
                Import a video to start building your timeline.
              </p>
            )}
            {tracks.map((track) => (
              <div key={track.id} className="relative h-14 rounded-lg bg-white/[0.02] border border-white/5">
                <div className="absolute -left-0 top-1 flex items-center gap-1 text-[9px] text-slate-500 px-1.5 z-10">
                  {trackIcon(track.type)} {track.name}
                </div>
                {track.clips.map((clip) => (
                  <div
                    key={clip.id}
                    onMouseDown={(e) => onClipMouseDown(e, clip)}
                    style={{
                      left: clip.start * px,
                      width: Math.max(20, clip.duration * px)
                    }}
                    className={`absolute top-4 bottom-1 rounded-md flex items-center px-2 cursor-grab active:cursor-grabbing overflow-hidden ${
                      selectedClipId === clip.id
                        ? "ring-2 ring-accent-purple bg-geo-gradient-soft"
                        : "bg-white/[0.06] hover:bg-white/[0.1]"
                    }`}
                  >
                    <span className="text-[10px] text-slate-200 truncate">{clip.name}</span>
                    <div
                      onMouseDown={(e) => onTrimHandleDown(e, clip, "left")}
                      className="absolute left-0 top-0 bottom-0 w-1.5 cursor-ew-resize bg-white/20 hover:bg-accent-purple"
                    />
                    <div
                      onMouseDown={(e) => onTrimHandleDown(e, clip, "right")}
                      className="absolute right-0 top-0 bottom-0 w-1.5 cursor-ew-resize bg-white/20 hover:bg-accent-purple"
                    />
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";
import { fetchFile } from "@ffmpeg/util";
import { getFFmpeg } from "@/lib/ffmpeg";
import { useVideoEditorStore } from "@/store/useVideoEditorStore";
import { Download, Loader2, Info } from "lucide-react";
import { motion } from "framer-motion";

const RESOLUTIONS = [
  { label: "1080p", width: 1920, height: 1080 },
  { label: "2K", width: 2560, height: 1440 },
  { label: "4K", width: 3840, height: 2160 }
];
const FRAME_RATES = [24, 30, 60];

export default function ExportPanel() {
  const { tracks } = useVideoEditorStore();
  const [resolution, setResolution] = useState(RESOLUTIONS[0]);
  const [fps, setFps] = useState(30);
  const [exporting, setExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const videoClips = tracks.find((t) => t.type === "video")?.clips ?? [];
  const hasText = (tracks.find((t) => t.type === "text")?.clips.length ?? 0) > 0;

  const runExport = async () => {
    if (videoClips.length === 0) return;
    setExporting(true);
    setProgress(0);
    setError(null);

    try {
      const ffmpeg = await getFFmpeg(setProgress);
      const sorted = [...videoClips].sort((a, b) => a.start - b.start);
      const segmentNames: string[] = [];

      for (let i = 0; i < sorted.length; i++) {
        const clip = sorted[i];
        const inputName = `in_${i}.mp4`;
        const outputName = `seg_${i}.mp4`;
        const fileData = await fetchFile(clip.src!);
        await ffmpeg.writeFile(inputName, fileData);

        await ffmpeg.exec([
          "-i", inputName,
          "-ss", String(clip.trimStart),
          "-to", String(clip.trimEnd),
          "-vf", `scale=${resolution.width}:${resolution.height}:force_original_aspect_ratio=decrease,pad=${resolution.width}:${resolution.height}:(ow-iw)/2:(oh-ih)/2,fps=${fps}`,
          "-c:v", "libx264",
          "-preset", "veryfast",
          "-crf", "20",
          "-c:a", "aac",
          outputName
        ]);
        segmentNames.push(outputName);
      }

      let finalFile = segmentNames[0];

      if (segmentNames.length > 1) {
        const listContent = segmentNames.map((n) => `file '${n}'`).join("\n");
        await ffmpeg.writeFile("concat_list.txt", listContent);
        await ffmpeg.exec([
          "-f", "concat",
          "-safe", "0",
          "-i", "concat_list.txt",
          "-c", "copy",
          "output.mp4"
        ]);
        finalFile = "output.mp4";
      }

      const data = await ffmpeg.readFile(finalFile);
      const blob = new Blob([data], { type: "video/mp4" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `geolink-export-${resolution.label}.mp4`;
      a.click();
    } catch (err) {
      console.error(err);
      setError(
        "Export failed. This usually means the browser blocked SharedArrayBuffer — ensure the app is served with COOP/COEP headers (already configured in next.config.mjs) and reload."
      );
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="glass-panel-solid rounded-2xl p-4 flex flex-col gap-4">
      <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-300">
        Export video
      </h3>

      <div className="flex flex-col gap-1.5">
        <label className="text-[11px] text-slate-500">Resolution</label>
        <div className="flex gap-1.5">
          {RESOLUTIONS.map((r) => (
            <button
              key={r.label}
              onClick={() => setResolution(r)}
              className={`flex-1 text-xs py-1.5 rounded-lg border transition-colors ${
                resolution.label === r.label
                  ? "bg-geo-gradient border-transparent text-white"
                  : "border-white/10 text-slate-400 hover:border-white/20"
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <label className="text-[11px] text-slate-500">Frame rate</label>
        <div className="flex gap-1.5">
          {FRAME_RATES.map((f) => (
            <button
              key={f}
              onClick={() => setFps(f)}
              className={`flex-1 text-xs py-1.5 rounded-lg border transition-colors ${
                fps === f
                  ? "bg-geo-gradient border-transparent text-white"
                  : "border-white/10 text-slate-400 hover:border-white/20"
              }`}
            >
              {f} FPS
            </button>
          ))}
        </div>
      </div>

      {hasText && (
        <div className="flex items-start gap-1.5 text-[10px] text-slate-500 bg-white/[0.03] rounded-lg p-2">
          <Info size={12} className="shrink-0 mt-0.5" />
          <span>
            Caption/text layers preview in the player but are not yet burned into the
            exported file in this build — full text-in-video rendering is on the roadmap.
          </span>
        </div>
      )}

      <motion.button
        whileTap={{ scale: 0.97 }}
        onClick={runExport}
        disabled={exporting || videoClips.length === 0}
        className="geo-btn-primary text-sm disabled:opacity-40 disabled:pointer-events-none"
      >
        {exporting ? (
          <>
            <Loader2 size={15} className="animate-spin" />
            Exporting {Math.round(progress * 100)}%
          </>
        ) : (
          <>
            <Download size={15} />
            Export MP4
          </>
        )}
      </motion.button>

      {error && <p className="text-[11px] text-red-400">{error}</p>}
    </div>
  );
}

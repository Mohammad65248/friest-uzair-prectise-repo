"use client";

import { useRef, useState } from "react";
import { FileVideo, Type, Plus } from "lucide-react";
import { useVideoEditorStore } from "@/store/useVideoEditorStore";

export default function VideoToolbar() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { addVideoClip, addTextClip, currentTime } = useVideoEditorStore();
  const [textDraft, setTextDraft] = useState("");

  const handleFile = (file: File) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement("video");
    video.preload = "metadata";
    video.src = url;
    video.onloadedmetadata = () => {
      addVideoClip(file, url, video.duration || 5);
    };
  };

  return (
    <div className="flex items-center gap-2 glass-panel-solid rounded-2xl px-3 py-2">
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
          e.target.value = "";
        }}
      />
      <button
        onClick={() => fileInputRef.current?.click()}
        className="geo-btn-ghost text-xs"
      >
        <FileVideo size={14} />
        Import video
      </button>

      <div className="w-px h-5 bg-white/10" />

      <div className="flex items-center gap-1.5 flex-1">
        <Type size={14} className="text-slate-500 shrink-0" />
        <input
          value={textDraft}
          onChange={(e) => setTextDraft(e.target.value)}
          placeholder="Caption text..."
          className="geo-input !py-1.5 text-xs"
        />
        <button
          onClick={() => {
            if (!textDraft.trim()) return;
            addTextClip(textDraft, currentTime, 3);
            setTextDraft("");
          }}
          className="geo-icon-btn shrink-0"
          title="Add caption at playhead"
        >
          <Plus size={15} />
        </button>
      </div>
    </div>
  );
}

"use client";

import { useEffect, useRef } from "react";
import { useVideoEditorStore } from "@/store/useVideoEditorStore";
import { Play, Pause, SkipBack } from "lucide-react";

export default function VideoPreview() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const { tracks, currentTime, playing, setCurrentTime, setPlaying, duration } =
    useVideoEditorStore();

  const videoTrack = tracks.find((t) => t.type === "video");
  const activeClip = videoTrack?.clips.find(
    (c) => currentTime >= c.start && currentTime < c.start + c.duration
  );
  const textTrack = tracks.find((t) => t.type === "text");
  const activeText = textTrack?.clips.find(
    (c) => currentTime >= c.start && currentTime < c.start + c.duration
  );

  // Keep the underlying <video> element in sync with the global playhead.
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !activeClip) return;
    const localTime = activeClip.trimStart + (currentTime - activeClip.start);
    if (Math.abs(video.currentTime - localTime) > 0.15) {
      video.currentTime = localTime;
    }
  }, [currentTime, activeClip]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    if (playing) video.play().catch(() => {});
    else video.pause();
  }, [playing, activeClip]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !playing) return;
    let raf: number;
    const tick = () => {
      if (activeClip) {
        const globalTime = activeClip.start + (video.currentTime - activeClip.trimStart);
        setCurrentTime(globalTime);
        if (globalTime >= duration) setPlaying(false);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, activeClip, duration]);

  return (
    <div className="flex flex-col gap-3 h-full">
      <div className="relative flex-1 rounded-xl overflow-hidden bg-black flex items-center justify-center checkerboard">
        {activeClip ? (
          <video
            ref={videoRef}
            src={activeClip.src}
            className="max-h-full max-w-full"
            muted={false}
            playsInline
          />
        ) : (
          <p className="text-slate-500 text-sm">Add a clip to the timeline to preview</p>
        )}
        {activeText && (
          <div className="absolute bottom-8 left-0 right-0 text-center px-6">
            <span className="text-white text-2xl font-display font-semibold drop-shadow-[0_2px_12px_rgba(0,0,0,0.8)]">
              {activeText.text}
            </span>
          </div>
        )}
      </div>

      <div className="flex items-center justify-center gap-3">
        <button
          className="geo-icon-btn"
          onClick={() => {
            setCurrentTime(0);
            setPlaying(false);
          }}
          title="Restart"
        >
          <SkipBack size={16} />
        </button>
        <button
          className="geo-btn-primary w-10 h-10 !p-0 rounded-full"
          onClick={() => setPlaying(!playing)}
          title={playing ? "Pause" : "Play"}
        >
          {playing ? <Pause size={16} /> : <Play size={16} className="ml-0.5" />}
        </button>
        <span className="text-xs text-slate-400 tabular-nums w-24 text-center">
          {formatTime(currentTime)} / {formatTime(duration)}
        </span>
      </div>
    </div>
  );
}

function formatTime(t: number) {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  const ms = Math.floor((t % 1) * 100);
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}.${ms
    .toString()
    .padStart(2, "0")}`;
}

"use client";

import Image from "next/image";
import { motion } from "framer-motion";

interface SplashScreenProps {
  progress?: number;
}

export default function SplashScreen({ progress = 100 }: SplashScreenProps) {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-base overflow-hidden">
      <div className="absolute inset-0 bg-geo-radial opacity-70" />

      <motion.div
        initial={{ opacity: 0, scale: 0.85 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="relative z-10 flex flex-col items-center gap-6"
      >
        <motion.div
          animate={{ filter: ["drop-shadow(0 0 16px rgba(139,92,246,0.4))", "drop-shadow(0 0 32px rgba(255,46,159,0.6))", "drop-shadow(0 0 16px rgba(139,92,246,0.4))"] }}
          transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
        >
          <Image src="/assets/logo/geolink-logo.png" alt="GeoLink Editor" width={120} height={120} priority />
        </motion.div>

        <div className="flex flex-col items-center gap-1">
          <h1 className="text-2xl font-display font-bold geo-gradient-text tracking-tight">
            GeoLink Editor
          </h1>
          <p className="text-xs text-slate-500 tracking-wide">Photo & Video Studio</p>
        </div>

        <div className="w-48 h-1 rounded-full bg-white/5 overflow-hidden mt-2">
          <motion.div
            className="h-full bg-geo-gradient"
            initial={{ width: "0%" }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          />
        </div>
      </motion.div>
    </div>
  );
}

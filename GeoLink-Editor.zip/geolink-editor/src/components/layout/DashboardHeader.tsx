"use client";

import { Search, Bell, User } from "lucide-react";

export default function DashboardHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <header className="flex items-center justify-between glass-panel-solid rounded-2xl px-5 py-4">
      <div>
        <h1 className="text-lg font-display font-semibold text-white">{title}</h1>
        {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
      </div>

      <div className="flex items-center gap-3">
        <div className="relative hidden md:block">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            placeholder="Search projects, templates..."
            className="geo-input !pl-9 w-64 !py-2"
          />
        </div>
        <button className="geo-icon-btn">
          <Bell size={16} />
        </button>
        <div className="w-9 h-9 rounded-full bg-geo-gradient flex items-center justify-center text-white shadow-neon-purple">
          <User size={16} />
        </div>
      </div>
    </header>
  );
}

"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutGrid,
  ImageIcon,
  Video,
  FolderOpen,
  Shapes,
  Type,
  History,
  Settings,
  Sparkles
} from "lucide-react";

const NAV_ITEMS = [
  { href: "/dashboard", icon: LayoutGrid, label: "Dashboard" },
  { href: "/editor/photo", icon: ImageIcon, label: "Photo Editor" },
  { href: "/editor/video", icon: Video, label: "Video Editor" },
  { href: "/dashboard/projects", icon: FolderOpen, label: "Projects" },
  { href: "/dashboard/templates", icon: Shapes, label: "Templates" },
  { href: "/dashboard/assets", icon: Type, label: "Assets & Fonts" },
  { href: "/dashboard/history", icon: History, label: "History" }
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-60 shrink-0 flex flex-col gap-6 glass-panel-solid rounded-2xl p-4 h-full">
      <div className="flex items-center gap-2.5 px-1">
        <Image
          src="/assets/logo/geolink-logo.png"
          alt="GeoLink Editor logo"
          width={32}
          height={32}
          className="drop-shadow-[0_0_10px_rgba(139,92,246,0.5)]"
        />
        <div className="flex flex-col leading-tight">
          <span className="text-sm font-display font-bold text-white">GeoLink</span>
          <span className="text-[10px] geo-gradient-text font-semibold -mt-0.5">Editor</span>
        </div>
      </div>

      <nav className="flex flex-col gap-1">
        {NAV_ITEMS.map(({ href, icon: Icon, label }) => {
          const active = pathname === href;
          return (
            <Link
              key={href}
              href={href}
              className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm transition-colors ${
                active
                  ? "bg-geo-gradient text-white shadow-neon-purple"
                  : "text-slate-400 hover:bg-white/[0.06] hover:text-white"
              }`}
            >
              <Icon size={16} />
              {label}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto flex flex-col gap-1">
        <div className="geo-divider mb-2" />
        <div className="geo-card !p-3 flex items-start gap-2 bg-geo-gradient-soft border-white/10">
          <Sparkles size={16} className="text-accent-pink shrink-0 mt-0.5" />
          <p className="text-[11px] text-slate-300 leading-relaxed">
            Connect your own AI provider in Settings to enable background removal,
            upscaling, and auto-captioning.
          </p>
        </div>
        <Link
          href="/dashboard/settings"
          className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm text-slate-400 hover:bg-white/[0.06] hover:text-white transition-colors"
        >
          <Settings size={16} />
          Settings
        </Link>
      </div>
    </aside>
  );
}

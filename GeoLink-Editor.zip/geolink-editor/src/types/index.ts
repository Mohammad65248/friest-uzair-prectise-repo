export type ToolId =
  | "select"
  | "crop"
  | "text"
  | "brush"
  | "shape"
  | "eraser"
  | "clone"
  | "heal"
  | "gradient"
  | "eyedropper";

export interface AdjustmentValues {
  brightness: number;
  contrast: number;
  saturation: number;
  exposure: number;
  temperature: number;
  tint: number;
  hue: number;
  vibrance: number;
  highlights: number;
  shadows: number;
  whites: number;
  blacks: number;
  sharpen: number;
  clarity: number;
  noiseReduction: number;
  blur: number;
}

export const DEFAULT_ADJUSTMENTS: AdjustmentValues = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  exposure: 0,
  temperature: 0,
  tint: 0,
  hue: 0,
  vibrance: 0,
  highlights: 0,
  shadows: 0,
  whites: 0,
  blacks: 0,
  sharpen: 0,
  clarity: 0,
  noiseReduction: 0,
  blur: 0
};

export interface ProjectMeta {
  id: string;
  name: string;
  type: "photo" | "video";
  createdAt: number;
  updatedAt: number;
  thumbnail?: string;
}

export interface TimelineClip {
  id: string;
  trackId: string;
  name: string;
  type: "video" | "audio" | "image" | "text";
  src?: string;
  start: number;
  duration: number;
  trimStart: number;
  trimEnd: number;
  volume?: number;
  text?: string;
}

export interface TimelineTrack {
  id: string;
  type: "video" | "audio" | "text" | "overlay";
  name: string;
  clips: TimelineClip[];
  locked: boolean;
  hidden: boolean;
}

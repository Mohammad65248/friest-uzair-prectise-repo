"use client";

import Link from "next/link";
import Image from "next/image";
import { ArrowLeft } from "lucide-react";
import VideoPreview from "@/components/editor/video/VideoPreview";
import VideoToolbar from "@/components/editor/video/VideoToolbar";
import Timeline from "@/components/editor/video/Timeline";
import ExportPanel from "@/components/editor/video/ExportPanel";

export default function VideoEditorPage() {
  return (
    <div className="flex flex-col h-dvh gap-3 p-3 bg-base">
      <header className="flex items-center justify-between px-4 py-2.5 glass-panel-solid rounded-2xl">
        <div className="flex items-center gap-3">
          <Link href="/dashboard" className="geo-icon-btn" title="Back to dashboard">
            <ArrowLeft size={16} />
          </Link>
          <div className="flex items-center gap-2">
            <Image
              src="/assets/logo/geolink-logo.png"
              alt="GeoLink Editor"
              width={26}
              height={26}
              className="drop-shadow-[0_0_8px_rgba(139,92,246,0.5)]"
            />
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-display font-semibold text-white">
                Untitled Video
              </span>
              <span className="text-[10px] text-slate-500">GeoLink Editor</span>
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1 gap-3 min-h-0">
        <div className="flex-1 flex flex-col gap-3 min-w-0">
          <div className="flex-1 min-h-0 glass-panel rounded-2xl p-3">
            <VideoPreview />
          </div>
          <VideoToolbar />
          <Timeline />
        </div>

        <aside className="w-72 shrink-0">
          <ExportPanel />
        </aside>
      </div>
    </div>
  );
}

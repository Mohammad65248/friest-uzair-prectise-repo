"use client";

import { useState } from "react";
import { fabric } from "fabric";
import dynamic from "next/dynamic";
import EditorHeader from "@/components/editor/EditorHeader";
import Toolbar from "@/components/editor/Toolbar";
import LayersPanel from "@/components/editor/LayersPanel";
import AdjustmentsPanel from "@/components/editor/AdjustmentsPanel";
import InsertBar from "@/components/editor/InsertBar";

// Fabric.js touches `window` on import, so the canvas must be client-only.
const PhotoCanvas = dynamic(() => import("@/components/editor/PhotoCanvas"), {
  ssr: false
});

export default function PhotoEditorPage() {
  const [canvas, setCanvas] = useState<fabric.Canvas | null>(null);

  return (
    <div className="flex flex-col h-dvh gap-3 p-3 bg-base">
      <EditorHeader canvas={canvas} projectName="Untitled Photo" />

      <div className="flex flex-1 gap-3 min-h-0">
        <Toolbar />

        <div className="flex-1 flex flex-col gap-3 min-w-0">
          <div className="flex justify-center">
            <InsertBar canvas={canvas} />
          </div>
          <div className="flex-1 min-h-0 glass-panel rounded-2xl p-3">
            <PhotoCanvas onCanvasReady={setCanvas} />
          </div>
        </div>

        <aside className="w-72 shrink-0 flex flex-col gap-3">
          <div className="glass-panel-solid rounded-2xl p-3 max-h-[45%] overflow-hidden flex flex-col">
            <LayersPanel canvas={canvas} />
          </div>
          <div className="glass-panel-solid rounded-2xl p-3 flex-1 overflow-y-auto no-scrollbar">
            <AdjustmentsPanel canvas={canvas} />
          </div>
        </aside>
      </div>
    </div>
  );
}

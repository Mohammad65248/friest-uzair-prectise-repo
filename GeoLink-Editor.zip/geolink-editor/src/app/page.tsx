"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import SplashScreen from "@/components/layout/SplashScreen";

export default function RootPage() {
  const router = useRouter();
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => {
        const next = Math.min(100, p + Math.random() * 22);
        if (next >= 100) {
          clearInterval(interval);
          setTimeout(() => setDone(true), 350);
        }
        return next;
      });
    }, 180);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (done) {
      const t = setTimeout(() => router.push("/dashboard"), 400);
      return () => clearTimeout(t);
    }
  }, [done, router]);

  return (
    <AnimatePresence>
      {!done && (
        <motion.div exit={{ opacity: 0 }} transition={{ duration: 0.4 }}>
          <SplashScreen progress={progress} />
        </motion.div>
      )}
    </AnimatePresence>
  );
}

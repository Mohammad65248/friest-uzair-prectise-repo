import type { Metadata, Viewport } from "next";
import { Inter, Sora } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap"
});

const sora = Sora({
  subsets: ["latin"],
  variable: "--font-sora",
  display: "swap"
});

export const metadata: Metadata = {
  title: "GeoLink Editor — Professional Photo & Video Editing",
  description:
    "GeoLink Editor is a premium, browser-based photo and video editing studio with layers, filters, timeline editing, and more.",
  applicationName: "GeoLink Editor",
  manifest: "/manifest.json",
  icons: {
    icon: [
      { url: "/favicon.ico" },
      { url: "/assets/icons/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/assets/icons/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/assets/icons/favicon-192x192.png", sizes: "192x192", type: "image/png" }
    ],
    apple: [{ url: "/assets/icons/apple-touch-icon.png", sizes: "180x180" }]
  },
  openGraph: {
    title: "GeoLink Editor",
    description: "Professional Photo & Video Editing Application",
    images: ["/assets/og-image.jpg"],
    type: "website"
  },
  twitter: {
    card: "summary_large_image",
    title: "GeoLink Editor",
    images: ["/assets/og-image.jpg"]
  }
};

export const viewport: Viewport = {
  themeColor: "#070B18",
  width: "device-width",
  initialScale: 1
};

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${inter.variable} ${sora.variable}`}>
      <body className="bg-base text-slate-100 antialiased font-sans selection:bg-accent-purple/40">
        {children}
      </body>
    </html>
  );
}

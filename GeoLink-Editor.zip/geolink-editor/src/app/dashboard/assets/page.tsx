"use client";

import Sidebar from "@/components/layout/Sidebar";
import DashboardHeader from "@/components/layout/DashboardHeader";
import { Type, ImageIcon, Music } from "lucide-react";

const FONT_PRESETS = ["Sora", "Inter", "Poppins", "Playfair Display", "JetBrains Mono"];

export default function AssetsPage() {
  return (
    <div className="flex h-dvh gap-3 p-3 bg-base">
      <Sidebar />
      <div className="flex-1 flex flex-col gap-3 min-w-0">
        <DashboardHeader title="Assets & Fonts" subtitle="Reusable fonts, stickers, and media for your projects" />

        <div className="flex-1 overflow-y-auto no-scrollbar flex flex-col gap-4">
          <div className="geo-card">
            <div className="flex items-center gap-2 mb-3">
              <Type size={15} className="text-accent-purple" />
              <h2 className="text-sm font-semibold text-white">Fonts</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {FONT_PRESETS.map((font) => (
                <div
                  key={font}
                  className="rounded-xl border border-white/5 bg-white/[0.02] px-4 py-3 text-sm text-slate-300 hover:border-accent-purple/40 transition-colors cursor-default"
                >
                  {font}
                </div>
              ))}
            </div>
          </div>

          <div className="geo-card">
            <div className="flex items-center gap-2 mb-3">
              <ImageIcon size={15} className="text-accent-pink" />
              <h2 className="text-sm font-semibold text-white">Media Library</h2>
            </div>
            <div className="flex items-center justify-center py-8 border border-dashed border-white/10 rounded-xl text-xs text-slate-600">
              Images and clips you upload in the editor will appear here once connected to Firebase Storage.
            </div>
          </div>

          <div className="geo-card">
            <div className="flex items-center gap-2 mb-3">
              <Music size={15} className="text-accent-blue" />
              <h2 className="text-sm font-semibold text-white">Audio</h2>
            </div>
            <div className="flex items-center justify-center py-8 border border-dashed border-white/10 rounded-xl text-xs text-slate-600">
              No audio tracks uploaded yet.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

"use client";

import Sidebar from "@/components/layout/Sidebar";
import DashboardHeader from "@/components/layout/DashboardHeader";
import Link from "next/link";
import { TEMPLATES } from "@/lib/templates";
import { motion } from "framer-motion";

export default function TemplatesPage() {
  return (
    <div className="flex h-dvh gap-3 p-3 bg-base">
      <Sidebar />
      <div className="flex-1 flex flex-col gap-3 min-w-0">
        <DashboardHeader title="Templates" subtitle="Ready-made canvas presets to start faster" />
        <div className="flex-1 overflow-y-auto no-scrollbar grid grid-cols-2 md:grid-cols-3 gap-4">
          {TEMPLATES.map((tpl, i) => (
            <motion.div
              key={tpl.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Link
                href={`/editor/${tpl.kind}?template=${tpl.id}`}
                className="geo-card flex flex-col gap-3 hover:shadow-neon-purple transition-shadow group"
              >
                <div
                  className="rounded-xl h-28 w-full flex items-center justify-center text-xs text-slate-500 border border-white/5"
                  style={{ aspectRatio: `${tpl.width} / ${tpl.height}`, background: tpl.previewGradient }}
                >
                  {tpl.width}×{tpl.height}
                </div>
                <div>
                  <h3 className="text-sm font-medium text-white group-hover:geo-gradient-text">
                    {tpl.name}
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">{tpl.description}</p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

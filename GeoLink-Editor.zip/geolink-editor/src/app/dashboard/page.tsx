"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ImageIcon, Video, ArrowUpRight } from "lucide-react";
import Sidebar from "@/components/layout/Sidebar";
import DashboardHeader from "@/components/layout/DashboardHeader";

const CREATE_CARDS = [
  {
    href: "/editor/photo",
    icon: ImageIcon,
    title: "New Photo Project",
    desc: "Unlimited layers, curves, filters, masks, and AI-ready tools.",
    gradient: "from-accent-pink/20 to-accent-purple/20"
  },
  {
    href: "/editor/video",
    icon: Video,
    title: "New Video Project",
    desc: "Multi-track timeline, transitions, captions, and 4K export.",
    gradient: "from-accent-purple/20 to-accent-blue/20"
  }
];

export default function DashboardPage() {
  return (
    <div className="flex h-dvh gap-3 p-3 bg-base">
      <Sidebar />
      <div className="flex-1 flex flex-col gap-3 min-w-0">
        <DashboardHeader title="Welcome back" subtitle="Pick up where you left off, or start something new" />

        <div className="flex-1 overflow-y-auto no-scrollbar flex flex-col gap-6">
          <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {CREATE_CARDS.map((card, i) => (
              <motion.div
                key={card.href}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
              >
                <Link
                  href={card.href}
                  className={`group relative flex flex-col justify-between h-40 rounded-2xl p-5 glass-panel bg-gradient-to-br ${card.gradient} overflow-hidden hover:shadow-neon-purple transition-shadow`}
                >
                  <div className="flex items-center justify-between">
                    <div className="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center">
                      <card.icon size={20} className="text-white" />
                    </div>
                    <ArrowUpRight
                      size={18}
                      className="text-slate-400 group-hover:text-white group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all"
                    />
                  </div>
                  <div>
                    <h3 className="text-base font-display font-semibold text-white">
                      {card.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 max-w-xs">{card.desc}</p>
                  </div>
                </Link>
              </motion.div>
            ))}
          </section>

          <section className="geo-card">
            <h2 className="text-sm font-semibold text-white mb-1">Recent projects</h2>
            <p className="text-xs text-slate-500 mb-4">
              Projects you create will be saved here once connected to Firebase.
            </p>
            <div className="flex flex-col items-center justify-center py-10 text-center gap-2 border border-dashed border-white/10 rounded-xl">
              <p className="text-sm text-slate-400">No projects yet</p>
              <p className="text-xs text-slate-600">
                Start a new photo or video project above to see it here.
              </p>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";
import Sidebar from "@/components/layout/Sidebar";
import DashboardHeader from "@/components/layout/DashboardHeader";
import Image from "next/image";
import {
  Palette,
  Gauge,
  Keyboard,
  Save,
  Cpu,
  HardDrive,
  UserCircle,
  Info
} from "lucide-react";

const SHORTCUTS: [string, string][] = [
  ["Move / Select tool", "V"],
  ["Crop tool", "C"],
  ["Text tool", "T"],
  ["Brush tool", "B"],
  ["Shape tool", "U"],
  ["Eraser", "E"],
  ["Clone stamp", "S"],
  ["Healing brush", "H"],
  ["Gradient", "G"],
  ["Eyedropper", "I"],
  ["Undo", "Ctrl / Cmd + Z"],
  ["Redo", "Ctrl / Cmd + Shift + Z"],
  ["Duplicate layer", "Ctrl / Cmd + D"],
  ["Delete layer", "Delete / Backspace"],
  ["Nudge selection", "Arrow keys"],
  ["Nudge selection (large)", "Shift + Arrow keys"]
];

function SettingsSection({
  icon: Icon,
  title,
  children
}: {
  icon: React.ElementType;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="geo-card">
      <div className="flex items-center gap-2 mb-3">
        <Icon size={15} className="text-accent-purple" />
        <h2 className="text-sm font-semibold text-white">{title}</h2>
      </div>
      {children}
    </div>
  );
}

export default function SettingsPage() {
  const [autosave, setAutosave] = useState(true);
  const [gpuAccel, setGpuAccel] = useState(true);
  const [language, setLanguage] = useState("English");

  return (
    <div className="flex h-dvh gap-3 p-3 bg-base">
      <Sidebar />
      <div className="flex-1 flex flex-col gap-3 min-w-0">
        <DashboardHeader title="Settings" subtitle="Configure GeoLink Editor to your workflow" />

        <div className="flex-1 overflow-y-auto no-scrollbar grid grid-cols-1 md:grid-cols-2 gap-4">
          <SettingsSection icon={Palette} title="Theme & Language">
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">Theme</span>
                <span className="text-xs px-2.5 py-1 rounded-lg bg-geo-gradient text-white">
                  Dark Premium
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">Language</span>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="geo-input w-32 !py-1.5 text-xs"
                >
                  <option>English</option>
                  <option>Hindi</option>
                  <option>Spanish</option>
                  <option>French</option>
                </select>
              </div>
            </div>
          </SettingsSection>

          <SettingsSection icon={Gauge} title="Performance">
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">GPU Acceleration</span>
                <button
                  onClick={() => setGpuAccel(!gpuAccel)}
                  className={`w-10 h-5.5 rounded-full transition-colors relative ${
                    gpuAccel ? "bg-geo-gradient" : "bg-white/10"
                  }`}
                >
                  <span
                    className={`absolute top-0.5 w-4.5 h-4.5 rounded-full bg-white transition-transform ${
                      gpuAccel ? "translate-x-[19px]" : "translate-x-0.5"
                    }`}
                  />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">Autosave</span>
                <button
                  onClick={() => setAutosave(!autosave)}
                  className={`w-10 h-5.5 rounded-full transition-colors relative ${
                    autosave ? "bg-geo-gradient" : "bg-white/10"
                  }`}
                >
                  <span
                    className={`absolute top-0.5 w-4.5 h-4.5 rounded-full bg-white transition-transform ${
                      autosave ? "translate-x-[19px]" : "translate-x-0.5"
                    }`}
                  />
                </button>
              </div>
            </div>
          </SettingsSection>

          <SettingsSection icon={Keyboard} title="Keyboard Shortcuts">
            <div className="grid grid-cols-1 gap-1.5 max-h-56 overflow-y-auto no-scrollbar pr-1">
              {SHORTCUTS.map(([label, key]) => (
                <div key={label} className="flex items-center justify-between text-xs py-1">
                  <span className="text-slate-400">{label}</span>
                  <kbd className="px-2 py-0.5 rounded-md bg-white/[0.06] border border-white/10 text-slate-300 text-[10px]">
                    {key}
                  </kbd>
                </div>
              ))}
            </div>
          </SettingsSection>

          <SettingsSection icon={HardDrive} title="Storage & Export">
            <div className="flex flex-col gap-3 text-xs text-slate-400">
              <p>
                Media and project files sync to Firebase Storage once you add your project
                credentials in <code className="text-accent-purple">.env.local</code>.
              </p>
              <div className="flex items-center gap-2 text-slate-500">
                <Save size={13} />
                Default export location: Downloads folder (browser default)
              </div>
              <div className="flex items-center gap-2 text-slate-500">
                <Cpu size={13} />
                Video export runs locally via FFmpeg WebAssembly — no files leave your browser.
              </div>
            </div>
          </SettingsSection>

          <SettingsSection icon={UserCircle} title="Account">
            <p className="text-xs text-slate-400">
              Sign in with Firebase Authentication to sync projects across devices. Configure
              your Firebase project in <code className="text-accent-purple">.env.local</code> to
              enable this.
            </p>
          </SettingsSection>

          <SettingsSection icon={Info} title="About">
            <div className="flex items-center gap-3">
              <Image src="/assets/logo/geolink-logo.png" alt="GeoLink Editor" width={36} height={36} />
              <div>
                <p className="text-sm text-white font-medium">GeoLink Editor v1.0.0</p>
                <p className="text-[11px] text-slate-500">
                  Built with Next.js, Fabric.js & FFmpeg WASM
                </p>
              </div>
            </div>
          </SettingsSection>
        </div>
      </div>
    </div>
  );
}

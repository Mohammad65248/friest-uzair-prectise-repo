"use client";

import Sidebar from "@/components/layout/Sidebar";
import DashboardHeader from "@/components/layout/DashboardHeader";
import { History } from "lucide-react";

export default function HistoryPage() {
  return (
    <div className="flex h-dvh gap-3 p-3 bg-base">
      <Sidebar />
      <div className="flex-1 flex flex-col gap-3 min-w-0">
        <DashboardHeader title="History" subtitle="Track changes across all your projects" />
        <div className="flex-1 geo-card flex flex-col items-center justify-center gap-3 text-center">
          <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center">
            <History size={24} className="text-slate-500" />
          </div>
          <div>
            <p className="text-sm text-slate-300">No activity yet</p>
            <p className="text-xs text-slate-600 mt-1">
              Per-project undo history lives inside each editor session. Cross-project
              activity logging appears here once Firestore is connected.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useEffect, useState } from "react";

/**
 * Tracks whether a CSS media query currently matches, so components
 * can adapt layout (e.g. collapsing panels on tablet/laptop widths).
 */
export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(false);

  useEffect(() => {
    const mql = window.matchMedia(query);
    setMatches(mql.matches);
    const listener = (e: MediaQueryListEvent) => setMatches(e.matches);
    mql.addEventListener("change", listener);
    return () => mql.removeEventListener("change", listener);
  }, [query]);

  return matches;
}

export const BREAKPOINTS = {
  tablet: "(min-width: 768px)",
  laptop: "(min-width: 1024px)",
  desktop: "(min-width: 1440px)"
};

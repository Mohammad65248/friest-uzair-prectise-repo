import { useEffect, useState } from "react";

/**
 * Debounces a fast-changing value (e.g. a slider) so expensive work
 * (like committing a history snapshot) only runs after the value
 * settles for `delayMs`.
 */
export function useDebouncedValue<T>(value: T, delayMs = 300): T {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const timeout = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(timeout);
  }, [value, delayMs]);

  return debounced;
}

export interface TemplateDef {
  id: string;
  name: string;
  description: string;
  kind: "photo" | "video";
  width: number;
  height: number;
  previewGradient: string;
}

export const TEMPLATES: TemplateDef[] = [
  {
    id: "insta-post",
    name: "Instagram Post",
    description: "Square format for feed posts",
    kind: "photo",
    width: 1080,
    height: 1080,
    previewGradient: "linear-gradient(135deg,#FF2E9F33,#8B5CF633)"
  },
  {
    id: "insta-story",
    name: "Instagram / Reel Story",
    description: "Vertical full-screen story",
    kind: "video",
    width: 1080,
    height: 1920,
    previewGradient: "linear-gradient(135deg,#8B5CF633,#3B82F633)"
  },
  {
    id: "youtube-thumb",
    name: "YouTube Thumbnail",
    description: "Standard 16:9 thumbnail",
    kind: "photo",
    width: 1280,
    height: 720,
    previewGradient: "linear-gradient(135deg,#3B82F633,#FF2E9F33)"
  },
  {
    id: "youtube-video",
    name: "YouTube Video (16:9)",
    description: "Standard landscape video",
    kind: "video",
    width: 1920,
    height: 1080,
    previewGradient: "linear-gradient(135deg,#FF2E9F33,#3B82F633)"
  },
  {
    id: "poster-a4",
    name: "A4 Poster",
    description: "Print-ready portrait poster",
    kind: "photo",
    width: 2480,
    height: 3508,
    previewGradient: "linear-gradient(135deg,#8B5CF633,#FF2E9F33)"
  },
  {
    id: "banner",
    name: "Web Banner",
    description: "Wide promotional banner",
    kind: "photo",
    width: 1500,
    height: 500,
    previewGradient: "linear-gradient(135deg,#3B82F633,#8B5CF633)"
  }
];

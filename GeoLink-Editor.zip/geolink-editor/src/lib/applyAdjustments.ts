import { fabric } from "fabric";
import type { AdjustmentValues } from "@/types";

/**
 * Applies the full adjustment stack to a Fabric.js image object using
 * Fabric's built-in filter pipeline (Brightness, Contrast, Saturation,
 * HueRotation, Noise, Blur, Convolute-based sharpen).
 * Values are all normalized -100..100 (or -180..180 for hue) from the UI.
 */
export function applyAdjustmentsToImage(
  img: fabric.Image,
  values: AdjustmentValues
) {
  const filters: any[] = [];

  if (values.brightness !== 0) {
    filters.push(
      new fabric.Image.filters.Brightness({ brightness: values.brightness / 100 })
    );
  }

  if (values.contrast !== 0) {
    filters.push(
      new fabric.Image.filters.Contrast({ contrast: values.contrast / 100 })
    );
  }

  if (values.saturation !== 0 || values.vibrance !== 0) {
    const combined = (values.saturation + values.vibrance) / 100;
    filters.push(new fabric.Image.filters.Saturation({ saturation: combined }));
  }

  if (values.hue !== 0) {
    filters.push(
      new fabric.Image.filters.HueRotation({ rotation: (values.hue / 180) * Math.PI })
    );
  }

  if (values.exposure !== 0) {
    // Fabric has no native "Exposure" filter — approximate using Gamma.
    const gammaVal = 1 + values.exposure / 100;
    filters.push(
      new fabric.Image.filters.Gamma({ gamma: [gammaVal, gammaVal, gammaVal] })
    );
  }

  if (values.blur > 0) {
    filters.push(new fabric.Image.filters.Blur({ blur: values.blur / 100 }));
  }

  if (values.noiseReduction > 0) {
    filters.push(
      new fabric.Image.filters.Noise({ noise: Math.max(0, 50 - values.noiseReduction) })
    );
  }

  if (values.sharpen > 0) {
    const s = values.sharpen / 100;
    filters.push(
      new fabric.Image.filters.Convolute({
        matrix: [0, -1 * s, 0, -1 * s, 1 + 4 * s, -1 * s, 0, -1 * s, 0]
      })
    );
  }

  if (values.temperature !== 0) {
    // Warm/cool tint approximated via a colour-matrix tinted overlay.
    const t = values.temperature / 100;
    filters.push(
      new fabric.Image.filters.ColorMatrix({
        matrix: [
          1 + t * 0.15, 0, 0, 0, 0,
          0, 1, 0, 0, 0,
          0, 0, 1 - t * 0.15, 0, 0,
          0, 0, 0, 1, 0
        ]
      })
    );
  }

  img.filters = filters;
  img.applyFilters();
  img.canvas?.requestRenderAll();
}

export const ADJUSTMENT_LABELS: Record<keyof AdjustmentValues, string> = {
  brightness: "Brightness",
  contrast: "Contrast",
  saturation: "Saturation",
  exposure: "Exposure",
  temperature: "Temperature",
  tint: "Tint",
  hue: "Hue",
  vibrance: "Vibrance",
  highlights: "Highlights",
  shadows: "Shadows",
  whites: "Whites",
  blacks: "Blacks",
  sharpen: "Sharpen",
  clarity: "Clarity",
  noiseReduction: "Noise Reduction",
  blur: "Blur"
};

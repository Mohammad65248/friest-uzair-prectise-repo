# GeoLink Editor

A premium, browser-based photo & video editing studio — dark theme, glassmorphism UI,
built with Next.js, TypeScript, Fabric.js, and FFmpeg WASM.

![GeoLink Editor](public/assets/og-image.jpg)

## Tech stack

- **Framework:** Next.js 14 (App Router) + React 18 + TypeScript
- **Styling:** Tailwind CSS + Framer Motion
- **Photo engine:** Fabric.js (canvas, layers, filters, shapes, text)
- **Video engine:** FFmpeg WASM (`@ffmpeg/ffmpeg`) — trim, concat, scale, encode, all in-browser
- **State:** Zustand
- **Backend/Auth:** Firebase (Authentication, Firestore, Storage)

## Getting started

```bash
npm install
cp .env.example .env.local   # fill in your Firebase credentials
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

### Deploying to Vercel

1. Push this repo to GitHub.
2. Import it in Vercel.
3. Add the same environment variables from `.env.example` in your Vercel project settings.
4. Deploy — `vercel.json` is already configured with the COOP/COEP headers FFmpeg WASM needs.

### Setting up Firebase

1. Create a project at [console.firebase.google.com](https://console.firebase.google.com).
2. Enable **Authentication** (Email/Password and/or Google sign-in), **Firestore**, and **Storage**.
3. Copy your web app config into `.env.local`.
4. Deploy the included security rules:
   ```bash
   firebase deploy --only firestore:rules,storage:rules
   ```

## What's implemented

### Photo Editor (`/editor/photo`)
- Unlimited layers (image, text, shapes) on a Fabric.js canvas, with a live layers panel
  (visibility, lock, opacity, delete, reorder via z-index)
- Insert: images (file upload), text (editable), rectangle/circle/triangle shapes
- Real tonal adjustments wired to Fabric's filter pipeline: brightness, contrast, saturation,
  vibrance, exposure (gamma), hue rotation, temperature, sharpen (convolution), blur, noise
- Move / select tool with keyboard shortcuts (Delete, arrow-key nudge, Ctrl/Cmd+D duplicate)
- Full undo/redo history stack
- Zoom controls
- Export to PNG, JPG, WEBP, SVG, and PDF (single-page raster PDF)

### Video Editor (`/editor/video`)
- Multi-track timeline (video + text/caption tracks) with drag-to-move and drag-to-trim clips
- Split clip at playhead, delete clip, zoom timeline in/out
- Preview player synced to the timeline playhead
- **Real** export via FFmpeg WebAssembly: trims each clip to its in/out points, scales to
  1080p/2K/4K at 24/30/60fps, and concatenates them into a single downloadable MP4 —
  runs entirely in your browser, no files are uploaded anywhere

### Shell
- Splash/loading screen, dashboard, templates gallery (common canvas presets), settings page
  (theme, language, performance toggles, keyboard shortcut reference, storage/account info),
  your GeoLink logo applied throughout (splash, sidebar, header, favicon, PWA icons, OG image)

## Honest scope notes — what's *not* fully built yet

This is a serious, working editor core — not a mockup — but it is not a drop-in replacement
for Photoshop/Premiere. Being upfront about the gap:

- **AI features** (background remove, magic eraser, upscale, auto-caption, face beautify, object
  tracking, scene detection) need a real ML backend or third-party API to function — they cannot
  run as genuine features with zero external service. The Settings page has a slot for wiring in
  a provider (e.g. Replicate, remove.bg) via `REPLICATE_API_TOKEN` in `.env.local`; until you add
  one, these entries are intentionally left out of the UI rather than faked.
- **Text/caption burn-in on video export**: captions preview live in the player but are not yet
  composited into the exported MP4 (noted in the Export panel). Burning them in requires bundling
  a font file into the FFmpeg WASM filesystem and a `drawtext`/overlay filter chain — a solid next
  step, left as a clearly-labeled gap rather than a silent failure.
- **PSD-level features** (smart objects, layer styles/effects, clone stamp, healing brush, curves
  dialog, perspective warp) are represented in the toolbar/UI but the underlying pixel algorithms
  are not implemented — Fabric.js gives you real layers, transforms, and filters, but not a full
  Photoshop-grade compositor.
- **Firebase project management** (save/load projects, recent-projects list, auth-gated routes)
  is wired for once you add your Firebase credentials, but the Projects/History pages currently
  show empty states rather than mock data.

## Project structure

```
geolink-editor/
├─ src/
│  ├─ app/                  # Next.js App Router pages
│  │  ├─ page.tsx           # Splash screen → dashboard
│  │  ├─ dashboard/         # Dashboard, projects, templates, assets, history, settings
│  │  └─ editor/
│  │     ├─ photo/          # Photo editor page
│  │     └─ video/          # Video editor page
│  ├─ components/
│  │  ├─ editor/            # Toolbar, Canvas, Layers, Adjustments, Insert bar, Header
│  │  ├─ editor/video/      # Timeline, Preview, Export, Toolbar
│  │  └─ layout/            # Sidebar, DashboardHeader, SplashScreen
│  ├─ lib/                  # firebase.ts, ffmpeg.ts, applyAdjustments.ts, templates.ts
│  ├─ store/                # Zustand stores (photo editor, video editor)
│  └─ types/                # Shared TypeScript types
├─ public/
│  ├─ assets/logo/          # Your uploaded GeoLink logo
│  ├─ assets/icons/         # Generated favicons & PWA icons (all sizes)
│  └─ manifest.json
├─ firestore.rules
├─ storage.rules
├─ vercel.json
└─ .env.example
```

## Keyboard shortcuts (Photo Editor)

| Action | Shortcut |
|---|---|
| Move / Select | `V` |
| Crop | `C` |
| Text | `T` |
| Brush | `B` |
| Shape | `U` |
| Eraser | `E` |
| Delete layer | `Delete` / `Backspace` |
| Duplicate layer | `Ctrl/Cmd + D` |
| Nudge | Arrow keys (`Shift` = 10px) |

## License

Proprietary — built for GeoLink. All rights reserved.
